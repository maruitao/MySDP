/**
 *    Date : 2008-1-8
 *      by : Yang ZHANG  @ UQ
 *   Email : mokuram@itee.uq.edu.au
 *           zhangyang@nwsuaf.edu.cn
 *    
 * Project : Classification of Data Streams
 *
 * Description:
 *        ����������ݼ��ָ���������֣�
 *        	xxLabel.arff    : ��������������
 *          xxUnlabel.arff  : ����δ��ע����
 *          xxTesting.arff  : �������ݼ�
 *        �������ڶ��ַ������⡣
 * 
 * CommandLine:
 *     Usage: -f InputFile [-pos POSSize] [-un UNSize] [-v] [-reuse]
 *         -f     : the input ARFF file name
 *         -pos   : the size of POS training dataset, the first class is looked as POS
 *         -un    : the size of UN training dataset
 *         -v     : to look the second class as the POS class
 *         -reuse : to reuse the samples in UN dataset in TESTing dataset
 *         
 */

package cie.mrt;

import java.util.*;
import weka.core.*;
import utils.*;

public class ReformatDatasetNew {
	// input dataset file
	String strInputArff;
	// size of POS set
	int nPosSize;
	// size of UN set
	int nUnSize;
	// whether to take the second class as POS class
	// default : the first class is POS class
	boolean bInvert;
	// whether to reuse the data in UN file
	boolean bReuse;
	
	// the random generator
	Random rand=new Random();
	
	public void getOptions(String options[]) {
		if (options.length==0){
			Out.error("Usage: -f InputFile [-pos POSSize] [-un UNSize] [-v] [-reuse]");
		}

		nPosSize=100;
		nUnSize=100;
		bInvert=false;
		bReuse=false;

		try {
			String str=Utils.getOption("f", options);
			strInputArff=str;

			str=Utils.getOption("pos", options);
			if (str.compareTo("")!=0) {
				nPosSize=Integer.parseInt(str);
			}

			str=Utils.getOption("un", options);
			if (str.compareTo("")!=0) {
				nUnSize=Integer.parseInt(str);
			}

			bInvert=Utils.getFlag('v', options);
			
			bReuse =Utils.getFlag("reuse", options);
		} catch(Exception e){
			Out.error("Usage: -f InputFile [-pos POSSize] [-un UNSize] [-v] [-reuse]");
		}
	}
	
	public void printDebug(){
		Out.println("Input File : "+strInputArff);
		Out.println("POS Size   : "+nPosSize);
		Out.println("UN Size    : "+nUnSize);
		Out.println("Invert     : "+bInvert);
		Out.println("Reuse Un   : "+bReuse);
	}
	
	public static void main(String[] args) throws Exception{
		ReformatDataset reformat=new ReformatDataset();
		reformat.getOptions(args);
		reformat.printDebug();
		reformat.reformat();
	}

	public void reformat(){
		Instances data=In.getARFFDatasetFromFile(strInputArff);
		data.setClassIndex(data.numAttributes()-1);
		
		// invert?
		if (bInvert){
			invertClassLabel(data);
		}
		
		Instances pos=new Instances(data,10);
		Instances neg=new Instances(data,10);
		for (int i=0;i<data.numInstances();i++){
			Instance sample=data.instance(i);
			if (Utils.eq(sample.classValue(),0)){
				pos.add(sample);
			}else {
				neg.add(sample);
			}
		}
		
		if (pos.numInstances()<nPosSize){
			Out.println("Too much POS samples needed : "+nPosSize);
			Out.println("Could provide POS sample only : "+pos.numInstances());
			Out.error("");
		}
		
		if (data.numInstances()<nPosSize+nUnSize){
			Out.println("Too much samples needed : "+nPosSize+nUnSize);
			Out.println("Could provide only : "+data.numInstances());
			Out.error("");
		}
		
		// generate the POS dataset
		/*pos.randomize(rand);
		Instances temp=new Instances(data,10);
		for (int i=0;i<nPosSize*2/3;i++){
			temp.add(pos.instance(i));
		}
		Out.outputDataFile("xxLabel.arff", temp);
		
		// generate the UN dataset
		for (int i=nPosSize*2/3;i<pos.numInstances();i++){
			neg.add(pos.instance(i));
		}
		neg.randomize(rand);
		temp=new Instances(neg, 0, nUnSize*2/3);
		Out.outputDataFile("xxUnlabel.arff", temp);
		
		// generate the testing dataset
		if (bReuse) temp=neg;
		else temp=new Instances(neg, nUnSize, neg.numInstances()-nUnSize);
		Out.outputDataFile("xxTesting.arff", temp);*/
		
		//generate the POS DataSet
		
		
	}
	
	public void invertClassLabel(Instances data){
		String strPosClass=data.classAttribute().value(0);
		String strNegClass=data.classAttribute().value(1);
		
		
		data.renameAttributeValue(data.classIndex(), 0, strNegClass);
		data.renameAttributeValue(data.classIndex(), 1, strPosClass);
		
		for (int i=0;i<data.numInstances();i++){
			Instance sample=data.instance(i);
			if (Utils.eq(sample.classValue(),0)){
				sample.setClassValue(1);
			}else {
				sample.setClassValue(0);
			}
		}
	}
}
