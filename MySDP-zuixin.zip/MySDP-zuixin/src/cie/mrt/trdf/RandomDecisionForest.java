package cie.mrt.trdf;

import utils.MrtUtils;
import weka.core.Instances;



/**
 *  子类需修改：1.bagging 采样为随机80%  可设参数是否保持PN比例
 *  2.distributionInstance  函数修改，计算最终的类别概率
 *  3.
 */

public class RandomDecisionForest extends RandomForest {
	
	private static final long serialVersionUID = 3050601879800398303L;
	
	/**
	 *  aa为比例，PN->PU的比例，1-aa为P中实际留下来的P的比例 
	 */
	public double aa ; 
	String pnFile = "";
	public Instances auxDataset = null;  // 辅助数据集，指传入建模的数据集（SMOTE后的）
	public Instances puDataset = null ;  // 建模数据集，修改为PU的数据集 用于建模用
	public int posDatasize ;
	public int unlDatasize ;
	
	/** The size of each bag sample, as a percentage of the training size */
	  protected int m_BagSizePercent = 70;  // default 80 70 90 need try 有放回抽样
	
	/**
	 * 传入PN数据集，并指定aa比例，然后初始化得到修改后的PU数据集，并保存到本地
	 * @param auxFilePath  辅助集PN文件路径
	 */	
	  
//	public void  setDataset(String auxFilePath , double aa) throws Exception{
//		pnFile = auxFilePath;
//		auxDataset = In.getARFFDatasetFromFile(auxFilePath);
//		auxDataset.setClassIndex(auxDataset.numAttributes() - 1);
//		this.aa = aa ;
//		super.aa = aa ;
//		puDataset = MrtUtils.pnToPuWriteOrNot(auxDataset, aa, false);
//		puDataset.setClassIndex(puDataset.numAttributes() - 1);
//		posDatasize = MrtUtils.getPUnumber(puDataset)[0];
//		unlDatasize = MrtUtils.getPUnumber(puDataset)[1];
//	}
	  
	public void setDataset(Instances pDS, Instances uDS , double aa )throws Exception{
		this.aa = aa;
		super.aa = aa;
	}
	
	public void setDataset(Instances puDS , double  aa)throws Exception{
		puDataset = puDS ;
		this.aa = aa ;
		super.aa = aa ;
		posDatasize = MrtUtils.getPUnumber(puDataset)[0];
		unlDatasize = MrtUtils.getPUnumber(puDataset)[1];
		puDataset.setClassIndex(puDataset.numAttributes() - 1);
		
	}
	

	public double getAa() {
		return aa;
	}

	public void setAa(double aa) {
		this.aa = aa;
	}

}
