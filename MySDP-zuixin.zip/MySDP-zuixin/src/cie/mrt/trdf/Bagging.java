/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    Bagging.java
 *    Copyright (C) 1999 University of Waikato, Hamilton, New Zealand
 *
 */

package cie.mrt.trdf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import java.util.Vector;

import cie.mrt.pos.MainTestPOSC45;
import utils.In;
import utils.MrtUtils;
import utils.Out;
import weka.classifiers.Evaluation;
import weka.classifiers.RandomizableIteratedSingleClassifierEnhancer;
import weka.core.AdditionalMeasureProducer;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.Randomizable;
import weka.core.RevisionUtils;
import weka.core.TechnicalInformation;
import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;
import weka.core.TechnicalInformationHandler;
import weka.core.Utils;
import weka.core.WeightedInstancesHandler;

/**
 <!-- globalinfo-start --> 
 * Class for bagging a classifier to reduce variance.
 * Can do classification and regression depending on the base learner. <br/>
 * <br/>
 * For more information, see<br/>
 * <br/>
 * Leo Breiman (1996). Bagging predictors. Machine Learning. 24(2):123-140.
 * <p/>
 <!-- globalinfo-end -->
 * 
 <!-- technical-bibtex-start --> 
 * BibTeX:
 * 
 * <pre>
 * &#64;article{Breiman1996,
 *    author = {Leo Breiman},
 *    journal = {Machine Learning},
 *    number = {2},
 *    pages = {123-140},
 *    title = {Bagging predictors},
 *    volume = {24},
 *    year = {1996}
 * }
 * </pre>
 * <p/>
 <!-- technical-bibtex-end -->
 * 
 * <!-- options-start --> Valid options are:
 * <p/>
 * 
 * <pre>
 * -P
 *  Size of each bag, as a percentage of the
 *  training set size. (default 100)
 * </pre>
 * 
 * <pre>
 * -O
 *  Calculate the out of bag error.
 * </pre>
 * 
 * <pre>
 * -S &lt;num&gt;
 *  Random number seed.
 *  (default 1)
 * </pre>
 * 
 * <pre>
 * -I &lt;num&gt;
 *  Number of iterations.
 *  (default 10)
 * </pre>
 * 
 * <pre>
 * -D
 *  If set, classifier is run in debug mode and
 *  may output additional info to the console
 * </pre>
 * 
 * <pre>
 * -W
 *  Full name of base classifier.
 *  (default: weka.classifiers.trees.REPTree)
 * </pre>
 * 
 * <pre>
 * Options specific to classifier weka.classifiers.trees.REPTree:
 * </pre>
 * 
 * <pre>
 * -M &lt;minimum number of instances&gt;
 *  Set minimum number of instances per leaf (default 2).
 * </pre>
 * 
 * <pre>
 * -V &lt;minimum variance for split&gt;
 *  Set minimum numeric class variance proportion
 *  of train variance for split (default 1e-3).
 * </pre>
 * 
 * <pre>
 * -N &lt;number of folds&gt;
 *  Number of folds for reduced error pruning (default 3).
 * </pre>
 * 
 * <pre>
 * -S &lt;seed&gt;
 *  Seed for random data shuffling (default 1).
 * </pre>
 * 
 * <pre>
 * -P
 *  No pruning.
 * </pre>
 * 
 * <pre>
 * -L
 *  Maximum tree depth (default -1, no maximum)
 * </pre>
 * 
 <!-- options-end -->
 * 
 * Options after -- are passed to the designated classifier.
 * <p>
 * 
 * @author Eibe Frank (eibe@cs.waikato.ac.nz)
 * @author Len Trigg (len@reeltwo.com)
 * @author Richard Kirkby (rkirkby@cs.waikato.ac.nz)
 * @version $Revision: 9370 $
 */
public class Bagging extends RandomizableIteratedSingleClassifierEnhancer
    implements WeightedInstancesHandler, AdditionalMeasureProducer,
    TechnicalInformationHandler {
	
	
  public static final String tarTrainFile = "datasets/output/tarPUTrain.arff";
  /** for serialization */
  private static final long serialVersionUID = -5178288489778728847L;

  /** The size of each bag sample, as a percentage of the training size */
  protected int m_BagSizePercent = 70;  // 70 80 90  100(OOB_true) need  try  

  /** Whether to calculate the out of bag error */
  protected boolean m_CalcOutOfBag = false; // false  true

  /** The out of bag error that has been calculated */
  protected double m_OutOfBagError;
  
  /** inBag中横坐标是分类器个数， 纵坐标是该分类器下的样本，1为已采样，0为未采样 */
  boolean[][] inBag = null;
  
  /** 每个bag所实际抽取存放的InstancesData*/
  public Instances[]  bagData = null;  
  
  /** 未抽取前所有的InstancesData*/
  public Instances instancesData = null ;
  public Map<String, Double> insceDataMap = null ;
  public Instances transferData = null ;
  
  /** bag的数量， 就是随机森林中随机树的个数 */
  public int bagNums = 0 ;
  
  /** 每一棵树的权重，当建好树时，就在target上测试 ，得到AUC然后赋值为树权重 */
  public double[] treeWeight ;

  /** target目标数据集， PU集 */
  public Instances targetData ;
  
  /** 辅助集的  aa  PN->PU的比例  */ 
//  aaInAux  应该在bagging 对象创建时初始化
  public double aaInAux;

  
	public double[] getTreeWeight() {
		return treeWeight;
	}

	public void setTreeWeight(double[] treeWeight) {
		this.treeWeight = treeWeight;
	}

	public Instances getTargetData() {
		return targetData;
	}

	public void setTargetData(Instances targetData) {
		this.targetData = targetData;
	}

	public double getAaInAux() {
		return aaInAux;
	}

	public void setAaInAux(double aaInAux) {
		this.aaInAux = aaInAux;
	}

/**
   * Constructor.
   */
	public Bagging() {

		m_Classifier = new weka.classifiers.trees.REPTree();
//		mrt's add :  init the targetData  for  evaluate the AUC
		targetData = In.getARFFDatasetFromFile(tarTrainFile);
//		test:
	}

	public int getBagNums() {
		return bagNums;
	}

	public void setBagNums(int bagNums) {
		this.bagNums = bagNums;
	}
	
	public int getM_BagSizePercent() {
		return m_BagSizePercent;
	}

	public void setM_BagSizePercent(int m_BagSizePercent) {
		this.m_BagSizePercent = m_BagSizePercent;
	}

	public boolean isM_CalcOutOfBag() {
		return m_CalcOutOfBag;
	}

	public void setM_CalcOutOfBag(boolean m_CalcOutOfBag) {
		this.m_CalcOutOfBag = m_CalcOutOfBag;
	}

	public double getM_OutOfBagError() {
		return m_OutOfBagError;
	}

	public void setM_OutOfBagError(double m_OutOfBagError) {
		this.m_OutOfBagError = m_OutOfBagError;
	}



/**
   * Returns a string describing classifier
   * 
   * @return a description suitable for displaying in the explorer/experimenter
   *         gui
   */
  public String globalInfo() {

    return "Class for bagging a classifier to reduce variance. Can do classification "
        + "and regression depending on the base learner. \n\n"
        + "For more information, see\n\n"
        + getTechnicalInformation().toString();
  }

  /**
   * Returns an instance of a TechnicalInformation object, containing detailed
   * information about the technical background of this class, e.g., paper
   * reference or book this class is based on.
   * 
   * @return the technical information about this class
   */
  public TechnicalInformation getTechnicalInformation() {
    TechnicalInformation result;

    result = new TechnicalInformation(Type.ARTICLE);
    result.setValue(Field.AUTHOR, "Leo Breiman");
    result.setValue(Field.YEAR, "1996");
    result.setValue(Field.TITLE, "Bagging predictors");
    result.setValue(Field.JOURNAL, "Machine Learning");
    result.setValue(Field.VOLUME, "24");
    result.setValue(Field.NUMBER, "2");
    result.setValue(Field.PAGES, "123-140");

    return result;
  }

  /**
   * String describing default classifier.
   * 
   * @return the default classifier classname
   */
  @Override
  protected String defaultClassifierString() {

    return "weka.classifiers.trees.REPTree";
  }

  /**
   * Returns an enumeration describing the available options.
   * 
   * @return an enumeration of all the available options.
   */
  @Override
  public Enumeration listOptions() {

    Vector newVector = new Vector(2);

    newVector.addElement(new Option(
        "\tSize of each bag, as a percentage of the\n"
            + "\ttraining set size. (default 100)", "P", 1, "-P"));
    newVector.addElement(new Option("\tCalculate the out of bag error.", "O",
        0, "-O"));

    Enumeration enu = super.listOptions();
    while (enu.hasMoreElements()) {
      newVector.addElement(enu.nextElement());
    }
    return newVector.elements();
  }

  /**
   * Parses a given list of options.
   * <p/>
   * 
   <!-- options-start --> 
   * Valid options are:
   * <p/>
   * 
   * <pre>
   * -P
   *  Size of each bag, as a percentage of the
   *  training set size. (default 100)
   * </pre>
   * 
   * <pre>
   * -O
   *  Calculate the out of bag error.
   * </pre>
   * 
   * <pre>
   * -S &lt;num&gt;
   *  Random number seed.
   *  (default 1)
   * </pre>
   * 
   * <pre>
   * -I &lt;num&gt;
   *  Number of iterations.
   *  (default 10)
   * </pre>
   * 
   * <pre>
   * -D
   *  If set, classifier is run in debug mode and
   *  may output additional info to the console
   * </pre>
   * 
   * <pre>
   * -W
   *  Full name of base classifier.
   *  (default: weka.classifiers.trees.REPTree)
   * </pre>
   * 
   * <pre>
   * Options specific to classifier weka.classifiers.trees.REPTree:
   * </pre>
   * 
   * <pre>
   * -M &lt;minimum number of instances&gt;
   *  Set minimum number of instances per leaf (default 2).
   * </pre>
   * 
   * <pre>
   * -V &lt;minimum variance for split&gt;
   *  Set minimum numeric class variance proportion
   *  of train variance for split (default 1e-3).
   * </pre>
   * 
   * <pre>
   * -N &lt;number of folds&gt;
   *  Number of folds for reduced error pruning (default 3).
   * </pre>
   * 
   * <pre>
   * -S &lt;seed&gt;
   *  Seed for random data shuffling (default 1).
   * </pre>
   * 
   * <pre>
   * -P
   *  No pruning.
   * </pre>
   * 
   * <pre>
   * -L
   *  Maximum tree depth (default -1, no maximum)
   * </pre>
   * 
   <!-- options-end -->
   * 
   * Options after -- are passed to the designated classifier.
   * <p>
   * 
   * @param options the list of options as an array of strings
   * @throws Exception if an option is not supported
   */
  @Override
  public void setOptions(String[] options) throws Exception {

    String bagSize = Utils.getOption('P', options);
    if (bagSize.length() != 0) {
      setBagSizePercent(Integer.parseInt(bagSize));
    } else {
      setBagSizePercent(100);
    }

    setCalcOutOfBag(Utils.getFlag('O', options));

    super.setOptions(options);
  }

  /**
   * Gets the current settings of the Classifier.
   * 
   * @return an array of strings suitable for passing to setOptions
   */
  @Override
  public String[] getOptions() {

    String[] superOptions = super.getOptions();
    String[] options = new String[superOptions.length + 3];

    int current = 0;
    options[current++] = "-P";
    options[current++] = "" + getBagSizePercent();

    if (getCalcOutOfBag()) {
      options[current++] = "-O";
    }

    System.arraycopy(superOptions, 0, options, current, superOptions.length);

    current += superOptions.length;
    while (current < options.length) {
      options[current++] = "";
    }
    return options;
  }

  /**
   * Returns the tip text for this property
   * 
   * @return tip text for this property suitable for displaying in the
   *         explorer/experimenter gui
   */
  public String bagSizePercentTipText() {
    return "Size of each bag, as a percentage of the training set size.";
  }

  /**
   * 
   * Gets the size of each bag, as a percentage of the training set size.
   * @return the bag size, as a percentage.
   */
  public int getBagSizePercent() {

    return m_BagSizePercent;
  }

  /**
   * Sets the size of each bag, as a percentage of the training set size.
   * 
   * @param newBagSizePercent the bag size, as a percentage.
   */
  public void setBagSizePercent(int newBagSizePercent) {

    m_BagSizePercent = newBagSizePercent;
  }

  /**
   * Returns the tip text for this property
   * 
   * @return tip text for this property suitable for displaying in the
   *         explorer/experimenter gui
   */
  public String calcOutOfBagTipText() {
    return "Whether the out-of-bag error is calculated.";
  }

  /**
   * Set whether the out of bag error is calculated.
   * 
   * @param calcOutOfBag whether to calculate the out of bag error
   */
  public void setCalcOutOfBag(boolean calcOutOfBag) {

    m_CalcOutOfBag = calcOutOfBag;
  }

  /**
   * Get whether the out of bag error is calculated.
   * 
   * @return whether the out of bag error is calculated
   */
  public boolean getCalcOutOfBag() {

    return m_CalcOutOfBag;
  }

  /**
   * Gets the out of bag error that was calculated as the classifier was built.
   * 
   * @return the out of bag error
   */
  public double measureOutOfBagError() {

    return m_OutOfBagError;
  }

  /**
   * Returns an enumeration of the additional measure names.
   * 
   * @return an enumeration of the measure names
   */
  public Enumeration enumerateMeasures() {

    Vector newVector = new Vector(1);
    newVector.addElement("measureOutOfBagError");
    return newVector.elements();
  }

  /**
   * Returns the value of the named measure.
   * 
   * @param additionalMeasureName the name of the measure to query for its value
   * @return the value of the named measure
   * @throws IllegalArgumentException if the named measure is not supported
   */
  public double getMeasure(String additionalMeasureName) {

    if (additionalMeasureName.equalsIgnoreCase("measureOutOfBagError")) {
      return measureOutOfBagError();
    } else {
      throw new IllegalArgumentException(additionalMeasureName
          + " not supported (Bagging)");
    }
  }

  /**
   * Bagging method.
   * 
   * @param data the training data to be used for generating the bagged
   *          classifier.
   * @throws Exception if the classifier could not be built successfully
   *  mrt's modify: in Class Header , Line:173
   *  1.bagData --> bagData[j]
   *  2.inBag[][]  
   *  3.Instances[]  bagData[30]
   *  4.Instance  instanceData  最终要修改instanceData中的weight
   */
  @Override
  public void buildClassifier(Instances data) throws Exception {
	  
    // can classifier handle the data?
    getCapabilities().testWithFail(data);

    // remove instances with missing class
    data = new Instances(data);
    data.deleteWithMissingClass();
    super.buildClassifier(data); //父类的：实现方法 集成学习分类器的初步初始化

  //将传入数据集 赋值给本地变量 instancesData
    instancesData = new Instances(data, 0, data.numInstances());
    transferData = new Instances(data , 0);
//    for(int i = 0 ;i < 5 ; i++){
//    	transferData[i] = new Instances(instancesData , 0);
//    	Out.printCutLine1();
//    	Out.println("transferData["+i+"]:");
//    	Out.println(transferData[i]);
//    }
    
    
//    instancesData = data;
    instancesData.setClassIndex(instancesData.numAttributes() - 1);
    insceDataMap = new TreeMap<String, Double>();
//    对instancesData的 类别标签 排序 然后顺序装入 TreeMap中
    
    instancesData.sort(instancesData.classIndex());
    for(int i  = 0 ; i < instancesData.numInstances() ; i ++){
    	insceDataMap.put(instancesData.instance(i).toString(), 0.0);
    }
   
//    Out.println("test map:");   
//   Out.printMap(insceDataMap);
//   Out.println(insceDataMap.size());
//    pass the test!!!
    
//	得到Evaluation对象 ，并传入targetData
    Evaluation evaluation = new Evaluation(targetData);
    
    
    if (m_CalcOutOfBag && (m_BagSizePercent != 100)) {
      throw new IllegalArgumentException("Bag size needs to be 100% if "
          + "out-of-bag error is to be calculated!");
    }
    double bagpercent = (double)m_BagSizePercent / 100 ;
    int bagSize = (int)(instancesData.numInstances() * bagpercent) ;
    Random random = new Random(m_Seed) ;
//		 mrt's add:
//    这里可设置是否保持PN 比例采样  true 保持  false 不保持
//    bagData = MrtUtils.absoRandResample(instancesData, bagpercent , getBagNums(), false); 
//    不用上面的无放回抽样，而用下面的有放回抽样
    bagData = MrtUtils.resampleByPutback(instancesData, getBagNums()); 
    
    for (int j = 0; j < m_Classifiers.length; j++) {
    	 
      // create the in-bag dataset
      if (m_CalcOutOfBag) {
        inBag[j] = new boolean[instancesData.numInstances()]; 
//         bagData = resampleWithWeights(data, random, inBag[j]);
        bagData[j] = instancesData.resampleWithWeights(random, inBag[j]);
      } 
      else {// this is mrt's remove  and use my method :
    	  if (bagSize < instancesData.numInstances()) {
    		  bagData[j].randomize(random);
    	  }
      }

      if (m_Classifier instanceof Randomizable) {
        ((Randomizable) m_Classifiers[j]).setSeed(random.nextInt());
      }
  
      // build the classifier
      m_Classifiers[j].buildClassifier(bagData[j]);

    }// end for circle, and then ,we can calc the Incs's  weight

//    计算样本权重并完成实例迁移，写入到本地
    double[]  tempEval ;
    double treeWeight ;
    Instance tempInce  ;
    int tempIndex  ;
    double tmpWeight ;
    for(int i = 0  ; i< m_Classifiers.length ; i++){
    	tempEval = evaluation.evaluateModel(m_Classifiers[i], targetData);
//    	下面两个评价指标二选一 ， 具体根据实验结果确定
    	treeWeight = evaluation.weightedAreaUnderROC();
//    	treeWeight = evaluation.weightedFMeasure();
    	
    	for(int j = 0 ;j < bagData[i].numInstances() ;j++){
    		tempInce = bagData[i].instance(j);
    		tempIndex = MrtUtils.hasInclude(instancesData, tempInce);
//    		Out.println("tempInce-->" ); pass the test!!
//    		Out.println(tempInce);
//    		Out.println("tempIndex-->" + tempIndex);
    		if(insceDataMap.containsKey(tempInce.toString())){
    			tmpWeight = insceDataMap.get(tempInce.toString());
    			if(tempInce.stringValue(instancesData.classIndex()).equals("Y")){
    				tmpWeight = tmpWeight + treeWeight / (1 - aaInAux);
    				insceDataMap.put(tempInce.toString(), tmpWeight);
//    				System.out.println(insceDataMap.get(tempInce.toString()));
    			}
    			else if(tempInce.stringValue(instancesData.classIndex()).equals("N")){
    				tmpWeight = tmpWeight + treeWeight / (1 + aaInAux);
    				insceDataMap.put(tempInce.toString(), tmpWeight);
//    				System.out.println(insceDataMap.get(tempInce.toString()));
    			}
    		}
    	}
    }
    
// Out.println("test2  map:");  
// Out.printMap(insceDataMap);
// Out.println(insceDataMap.size());
//    pass the test!!
    
	 /**
	  * 将Map中的数据按value值排序，并选出样本权重高的样本
	  */
	 List<Map.Entry<String, Double>> list = 
	 		new ArrayList<Map.Entry<String,Double>>(insceDataMap.entrySet());
	 Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
	 	@Override
			public int compare(Entry<String, Double> o1, Entry<String, Double> o2) {
				// TODO Auto-generated method stub
				return o2.getValue().compareTo(o1.getValue()); // 降序排序！ pass test!!
			}
		});
	 
	 /*
	  * 下面的代码是将map中按权重前 0.1  0.2 .. 0.5  等样本赋值到transferData中
	  */
	 int numIncs = insceDataMap.size();
	 int pace = 0 ;
	 for(Map.Entry<String, Double> mapping : list){
//		 System.out.println(mapping.getKey() + " : " + mapping.getValue());
		 if(pace < targetData.numInstances() * 0.1){ //	  numIncs * 0.1  0.2  0.3  0.4  0.5  0.15
			 if((tempIndex = MrtUtils.hasInclude(instancesData, mapping.getKey()))!= -1){
				 instancesData.instance(tempIndex).setWeight(mapping.getValue());
			 }
		 }
		 pace ++ ;
	 }
	 transferData = MrtUtils.transferIncsByWeight(instancesData);
//	 Out.printIncsWithWeight(transferData); 
	 Out.outputDataFile("datasets/output/transfer03.arff", transferData);

	 Out.println("Bagging build finished!");
	 MainTestPOSC45.pritnMemory();  
//	 pass the test!!!
	 
	 
    // calc OOB error?
    if (getCalcOutOfBag()) {
      double outOfBagCount = 0.0;
      double errorSum = 0.0;
      boolean numeric = data.classAttribute().isNumeric();

      for (int i = 0; i < data.numInstances(); i++) {
        double vote;
        double[] votes;
        if (numeric)
          votes = new double[1];
        else
          votes = new double[data.numClasses()];

        // determine predictions for instance
        int voteCount = 0;
        for (int j = 0; j < m_Classifiers.length; j++) {
          if (inBag[j][i])
            continue;

          voteCount++;
          // double pred = m_Classifiers[j].classifyInstance(data.instance(i));
          if (numeric) {
            // votes[0] += pred;
            votes[0] = m_Classifiers[j].classifyInstance(data.instance(i));
          } else {
            // votes[(int) pred]++;
            double[] newProbs = m_Classifiers[j].distributionForInstance(data
                .instance(i));
            // average the probability estimates
            for (int k = 0; k < newProbs.length; k++) {
              votes[k] += newProbs[k];
            }
          }
        }

        // "vote"
        if (numeric) {
          vote = votes[0];
          if (voteCount > 0) {
            vote /= voteCount; // average
          }
        } else {
          if (Utils.eq(Utils.sum(votes), 0)) {
          } else {
            Utils.normalize(votes);
          }
          vote = Utils.maxIndex(votes); // predicted class
        }

        // error for instance
        outOfBagCount += data.instance(i).weight();
        if (numeric) {
          errorSum += StrictMath.abs(vote - data.instance(i).classValue())
              * data.instance(i).weight();
        } else {
          if (vote != data.instance(i).classValue())
            errorSum += data.instance(i).weight();
        }
      }

      m_OutOfBagError = errorSum / outOfBagCount;
      Out.println("OOB_error: " + m_OutOfBagError);
    } else {
      m_OutOfBagError = 0;
    }

  }

  /**
   * Calculates the class membership probabilities for the given test instance.
   * 
   * @param instance the instance to be classified
   * @return preedicted class probability distribution
   * @throws Exception if distribution can't be computed successfully
   */
//  maybe this method need modify
//  分类传入的数据集，并计算得出该样本权重  Instances[]  bagData
  @Override
  public double[] distributionForInstance(Instance instance) throws Exception {
//	{Y,N} Y for 0  and N for 1
    double[] sums = new double[instance.numClasses()], newProbs;

//    外循环，迭代10次，然后求平均
    for (int i = 0; i < m_NumIterations; i++) {
      if (instance.classAttribute().isNumeric() == true) {
        sums[0] += m_Classifiers[i].classifyInstance(instance);
      } else {
        newProbs = m_Classifiers[i].distributionForInstance(instance);
        for (int j = 0; j < newProbs.length; j++)
          sums[j] += newProbs[j];
      }
    }
    if (instance.classAttribute().isNumeric() == true) {// this way we will take place  
    	
      sums[0] /= m_NumIterations;
      return sums;
    } else if (Utils.eq(Utils.sum(sums), 0)) {
    	
    	
      return sums;
    } else {
      Utils.normalize(sums);
      return sums;
    }
  }
  

  

  /**
   * Returns description of the bagged classifier.
   * 
   * @return description of the bagged classifier as a string
   */
  @Override
  public String toString() {

    if (m_Classifiers == null) {
      return "Bagging: No model built yet.";
    }
    StringBuffer text = new StringBuffer();
    text.append("All the base classifiers: \n\n");
    for (int i = 0; i < m_Classifiers.length; i++)
      text.append(m_Classifiers[i].toString() + "\n\n");

    if (m_CalcOutOfBag) {
      text.append("Out of bag error: "
          + Utils.doubleToString(m_OutOfBagError, 4) + "\n\n");
    }

    return text.toString();
  }

  /**
   * Returns the revision string.
   * 
   * @return the revision
   */
  @Override
  public String getRevision() {
    return RevisionUtils.extract("$Revision: 9370 $");
  }

  /**
   * Main method for testing this class.
   * 
   * @param argv the options
 * @throws Exception 
   */
  public static void main(String[] argv) throws Exception {
//    runClassifier(new Bagging(), argv);
//	  Bagging b = new Bagging();
//	  Instances data = In.getARFFDatasetFromFile("xxTesting.arff");
//	  b.buildClassifier(data);
  }
}
