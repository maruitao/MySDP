package cie.mrt;

import utils.*;
import weka.core.Instances;
import weka.core.Instance;
import java.util.Random;

public class subDataset {
	public static void main(String args[]) throws Exception {
		Instances all = In.getARFFDatasetFromFile("e:\\spect.arff");
		Out.println(all.numInstances());
		Random rand = new Random();
		// all.randomize(rand);

		Instances test = new Instances(all, 89);
		for (int i = 0; i < 89; i++) {
			int r = rand.nextInt(all.numInstances());
			Instance temp = all.instance(r);
			test.add(temp);
			all.delete(r);
		}
		Out.println(all.numInstances());
		Out.outputDataFile("e:\\xxTesting.arff", test);
		Out.outputDataFile("e:\\new-spect.arff", all);

	}
}