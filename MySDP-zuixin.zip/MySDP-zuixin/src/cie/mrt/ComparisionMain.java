package cie.mrt;

import java.io.FileReader;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Random;

import utils.Out;
import utils.MrtUtils;
import weka.attributeSelection.CfsSubsetEval;
import weka.core.Attribute;
import weka.core.Instances;
import weka.filters.supervised.attribute.AttributeSelection;

/**
 * contrast experiment : get the 0kc3 and build model and classify it.
 * 
 * @author mart
 *
 */
public class ComparisionMain {

	public static void main(String[] args) throws Exception {

		/**
		 *  1.get the 0kc3 into the Instances
		 *  datasets/pckc/0kc3-numeric.arff
		 */
		FileReader fr = new FileReader("datasets/pckc/0kc3-numeric.arff");
		Instances instances = new Instances(fr);
		instances.setClassIndex(instances.numAttributes() - 1); // 设置属性索引，加快查找效率
		fr.close();

		/**  2.将数据集随机按比例分成 如5-5分 3-7分 */ 
		int sampleSize = instances.numInstances();
		// 构建只有属性没有数据单大小相同的数据集

		Instances[] traTest = new Instances[2];
		traTest = MrtUtils.divideIncs(instances, 0.5);

		/**  3.将训练集按照不同a=0.2 0.4 0.6 改为pu数据 */ 
//		Instances pu=MrtUtils.pnToPuWriteOrNot(instances, 0.2);
//		Out.printInstances(pu);
		
	}



}
