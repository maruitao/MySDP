/**
 *    Date : 2008-1-7
 *      by : Yang ZHANG  @ UQ
 *   Email : mokuram@itee.uq.edu.au
 *           zhangyang@nwsuaf.edu.cn
 *    
 * Project : Classification of Data Streams
 *
 * Description:
 *        Take POS + UN (with label) as training dataset,
 *        this is to test on TEST dataset, as baseline.
 */
package cie.mrt.pos.ex;


import utils.In;
import utils.Out;
import utils.Weka;
import weka.classifiers.*;
import weka.core.*;

public class ExJ48 {

	public static void main(String[] args) throws Exception{
		ExParameter param=new ExParameter();
		param.setParameter();
		
		ExJ48 ex=new ExJ48();
		ex.experiment(param);
	}
	
	public void experiment(ExParameter param) {
		try {
			// reading dataset
			Instances trainDataset1=In.getARFFDatasetFromFile(param.strLabelTrainFile);
			trainDataset1.setClassIndex(trainDataset1.numAttributes()-1);
			Instances trainDataset2=In.getARFFDatasetFromFile(param.strUnLabelTrainFile);
			trainDataset2.setClassIndex(trainDataset2.numAttributes()-1);
			
			Weka.addDataset(trainDataset1,trainDataset2);
			
			Classifier[] cla = new weka.classifiers.trees.J48[5];
			
			for(int i=0;i<5;i++)
			{
				cla[i]=new weka.classifiers.trees.J48();
				cla[i].setOptions(Utils.splitOptions(param.strC45Options));
				cla[i].buildClassifier(trainDataset1);
				
				Out.println(cla[i].toString());
			}
			
			
			Out.println("==============�������");
			for(int i=0;i<5;i++)
			{
				Out.println(cla[i].toString());
			}

			// testing
//			Instances testDataset=In.getARFFDatasetFromFile(param.strTestFile);
//			testDataset.setClassIndex(testDataset.numAttributes()-1);
//			weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(testDataset);
//			eval.evaluateModel(cla,testDataset);
//			
//			// print experiment result
//			Out.println(eval.toMatrixString());
//			Out.println(eval.toSummaryString());
//
//			Out.println("Classifier : "+Weka.getClassifierOptions(cla));
//			PrintfFormat pf=new PrintfFormat("%7.4f");
//			Out.println("ACCURACY by "+ClassInfo.GetClassName(cla)+"  : "+pf.sprintf(1-eval.errorRate()));
		}catch (Exception e){
			Out.error(e.toString(),e);
		}
	}

}
