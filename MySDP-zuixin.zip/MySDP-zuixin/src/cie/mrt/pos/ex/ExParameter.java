/**
 *    Date : 2008-1-9
 *      by : Yang ZHANG  @ UQ
 *   Email : mokuram@itee.uq.edu.au
 *           zhangyang@nwsuaf.edu.cn
 *    
 * Project : Classification of Data Streams
 *
 * Description:
 *        
 */
package cie.mrt.pos.ex;

public class ExParameter {
	public String strLabelTrainFile;
	public String strUnLabelTrainFile;
	public String strTestFile;
	public String strC45Options;
	
	// default parameter
	public void setParameter(){
		strLabelTrainFile  ="datasets/output/outposdata.arff";
		strUnLabelTrainFile="datasets/output/outunldata.arff";
		strTestFile        ="datasets/output/fTest.arff";
		strC45Options      ="-f datasets/pckc/0kc3-numeric.arff -pos 19 -un 79";
		
		//System.out.println(strLabelTrainFile + strUnLabelTrainFile + strTestFile + strC45Options);
	}
	
	public String toString(){
		StringBuffer sb = new StringBuffer();
		sb.append("strLabelTrainFile:");
		sb.append(strLabelTrainFile);
		sb.append("\n");
		sb.append("strUnLabelTrainFile:");
		sb.append(strUnLabelTrainFile);
		sb.append("\n");
		sb.append("strTestFile:");
		sb.append(strTestFile);
		sb.append("\n");
		sb.append("strC45Options:");
		sb.append(strC45Options);
		return sb.toString();
	}
}
