/**
 *    Date : 2008-1-9
 *      by : Yang ZHANG  @ UQ
 *   Email : mokuram@itee.uq.edu.au
 *           zhangyang@nwsuaf.edu.cn
 *    
 * Project : Classification of Data Streams
 *
 * Description:
 *        Experiment with C45PosUnl
 */
package cie.mrt.pos.ex;

import cie.mrt.pos.ClassifyPOSC45;
import utils.*;
import weka.classifiers.*;
import weka.core.*;

public class ExC45PosUnl {

	public static void main(String[] args) throws Exception{
		ExParameter param=new ExParameter();
		param.setParameter();
		Out.println("~~~~~~~~~~~~~");
		Out.println(param.toString());
		
		ExC45PosUnl ex=new ExC45PosUnl();
		ex.experiment(param);
	}
	
	public void experiment(ExParameter param) {
		try {
			ClassifyPOSC45 c45posunl =new ClassifyPOSC45(0.5);
			c45posunl.setDataset(param.strLabelTrainFile, param.strUnLabelTrainFile);
			c45posunl.setOptions(param.strC45Options);
			c45posunl.buildClassifier(null);
			Out.println(c45posunl.toString());
			
			// testing
			Instances testDataset=In.getARFFDatasetFromFile(param.strTestFile);
			//Instances testDataset=In.getARFFDatasetFromFile(param.strTestFile);
			testDataset.setClassIndex(testDataset.numAttributes()-1);
			Evaluation eval = new Evaluation(testDataset);
			eval.evaluateModel(c45posunl,testDataset);
			
			// print experiment result
			Out.println(eval.toMatrixString());
			Out.println(eval.toSummaryString());

			Out.println("Classifier : "+Weka.getClassifierOptions(c45posunl));
			PrintfFormat pf=new PrintfFormat("%7.4f");
			Out.println("ACCURACY by "+ClassInfo.GetClassName(c45posunl)+"  : "+pf.sprintf(1-eval.errorRate()));

		}catch (Exception e){
			Out.error(e.toString(),e);
		}
	}

}
