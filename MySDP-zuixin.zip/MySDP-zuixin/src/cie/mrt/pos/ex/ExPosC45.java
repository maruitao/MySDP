/**
 *    Date : 2008-1-9
 *      by : Yang ZHANG  @ UQ
 *   Email : mokuram@itee.uq.edu.au
 *           zhangyang@nwsuaf.edu.cn
 *    
 * Project : Classification of Data Streams
 *
 * Description:
 *        
 */

package cie.mrt.pos.ex;

import utils.In;
import utils.Out;
import utils.PrintfFormat;
import weka.classifiers.*;
import weka.core.*;
import cie.mrt.pos.PosC45;

import java.util.*;
import java.io.*;

public class ExPosC45
{

	public static void main(String[] args) throws Exception
	{
		ExParameter param = new ExParameter();
		param.setParameter();

		ExPosC45 ex = new ExPosC45();
		//System.out.println(args[0]);

		ex.experiment(param);
	}

	public void experiment(ExParameter param) throws Exception
	{

		try
		{
			Date d1 = new Date();
			long t1 = d1.getTime();

			
			//System.out.println(flag);
			//System.out.println(param.strLabelTrainFile + param.strUnLabelTrainFile + param.strC45Options);
			
			
			PosC45 posc45 = new PosC45();
			posc45.setDataset(param.strLabelTrainFile,param.strUnLabelTrainFile);
			posc45.setOptions(param.strC45Options);
			posc45.buildClassifier(null);


			// testing
			Instances testDataset = In.getARFFDatasetFromFile(param.strTestFile);
			// Instances
			testDataset.setClassIndex(testDataset.numAttributes() - 1);
			Evaluation eval = new Evaluation(testDataset);
			eval.evaluateModel(posc45, testDataset);

			Date d2 = new Date();
			long t2 = d2.getTime();

			// print experiment result
			Out.println(eval.toMatrixString());
			Out.println(eval.toSummaryString());

			
				try
				{
					File file = new File("e:\\result_kr-vs-kp(test-won).csv");
					
					FileWriter filewriter = new FileWriter(file, true);
					
					filewriter.append("\n");
					
					filewriter.write(Double.toString(1 - eval.errorRate()));
					
					filewriter.append(",");
					
					filewriter.flush();
					
					filewriter.close();
				}
				catch (IOException e)
				{
					throw e;
				}
				catch (Exception ex)
				{
					throw ex;
				}
			
			//Out.println("Classifier : " + Weka.getClassifierOptions(posc45));
			PrintfFormat pf = new PrintfFormat("%7.4f");
			//Out.println("ACCURACY by " + ClassInfo.GetClassName(posc45)
			//		+ "  : " + pf.sprintf(1 - eval.errorRate()));

			//posc45.printBasePerformance(testDataset);

			//Out.println("time is: " + (t2 - t1));
		}
		catch (Exception e)
		{
			Out.error(e.toString(), e);
		}
	}

}
