package cie.mrt.pos;

import weka.core.Instances;
import utils.*;

public class ClassifyPOSC45 extends J48 {

	private static final long serialVersionUID = 3144615351387981290L;
//	the POS dataset
	String strPosFileName;
	Instances posDataset;
//	the UNL dataset
	String strUnlFileName;
	Instances unDataset;
	
	public static  int nPosSize ;
	public static int nUnSize ;
	public static double dDF ;
	
	
	public ClassifyPOSC45(){
		dDF = 0.5;
	}

	public ClassifyPOSC45(double d){
		dDF = d;
	}
	
	/**
	 * 将正例和未标注文件，并生成对应数据集
	 * @param strPOSFile  正例数据文件路径
	 * @param strUNFile	  未标注数据文件路径
	 * @throws Exception  
	 */
	public void setDataset(String strPOSFile, String strUNFile)throws Exception{
		strPosFileName = strPOSFile;
		strUnlFileName = strUNFile;
		
		posDataset = In.getARFFDatasetFromFile(strPosFileName);
		posDataset.setClassIndex(posDataset.numAttributes() - 1); // set index can increase efficiency
		nPosSize = posDataset.numInstances();
		unDataset = In.getARFFDatasetFromFile(strUnlFileName);
		unDataset.setClassIndex(unDataset.numAttributes() - 1);
		nUnSize = unDataset.numInstances();
	}
	
	public void setDataset(Instances posData, Instances unData)throws Exception{
		posDataset = posData;
		unDataset = unData;
		posDataset.setClassIndex(posDataset.numAttributes() - 1);
		unDataset.setClassIndex(unDataset.numAttributes() - 1);
		nPosSize = posDataset.numInstances();
		nUnSize = unDataset.numInstances();
	}
	
	public void setOptions(String strOptions)throws Exception{
		super.setOptions(MrtUtils.spiltOptions(strOptions));
	}
	
	
	/**
	 * 具体实现过程：1.各自分PU数据集   train  test 
	 * @param instances 传入的参数   是PU下的learn
	 */
	public void buildClassifier(Instances puLearnData)throws Exception{
		
//		CutInto2 cut = new CutInto2();
//		Random rand = new Random();
//		Instances two[] = cut.randomize(rand.nextInt(), 67, posDataset);
//		Instances posLearnData = two[0];
//		Instances posTestData = two[1];
//		
//		two = cut.randomize(rand.nextInt(), 67, unDataset);
//		Instances unLearnData = two[0];
//		Instances unTestData = two[1];
//		
//		nPosSize = posLearnData.numInstances();
//		nUnSize = unLearnData.numInstances();
//		Instances mgeLearnData = MrtUtils.mergetIncs(posLearnData, unLearnData);
//		Instances mgeTestData = MrtUtils.mergetIncs(posTestData, unTestData);
		
		super.buildClassifier(puLearnData);
		
		
	}
	
//	public Instances createTrainingData(){
//		
//		
//	}
	
	

	
	
}//end of C45PosUnl class
