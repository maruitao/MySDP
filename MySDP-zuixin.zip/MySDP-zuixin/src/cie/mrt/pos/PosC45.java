package cie.mrt.pos;

import java.text.SimpleDateFormat;
import java.util.Date;

import utils.In;
import utils.MrtUtils;
import utils.Out;
import utils.PrintfFormat;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;

public class PosC45 extends Classifier {
	
	private static final long serialVersionUID = -7904382903277242670L;
/** 成员变量若不初始化，则会自动赋null值*/
//	the POS dataset  datasets/output/outposdata.arff
	String strPosFileName = "";  
	Instances posDataset = null ;
//	the UNL dataset  datasets/output/outunldata.arff
	String strUnlFileName = "" ;
	Instances unlDataset = null;
	
//	options for the base c45 classifier
	String strAlgorithm="";
	
//	the classifier
	public ClassifyPOSC45 claC45posunl;
	ClassifyPOSC45 c45posunl[];
	
//	P中正例变负例的比例
	public double aa = 0.2 ;
	
	
	public double getAa() {
		return aa;
	}

	public void setAa(double aa) {
		this.aa = aa;
	}

	public void setDataset(String strPOSFile, String strUNFile){
		strPosFileName = strPOSFile;
		strUnlFileName = strUNFile;

		posDataset = In.getARFFDatasetFromFile(strPosFileName);
		posDataset.setClassIndex(posDataset.numAttributes() - 1);
		unlDataset = In.getARFFDatasetFromFile(strUnlFileName);
		unlDataset.setClassIndex(unlDataset.numAttributes() - 1);
	}
	
	public void setDatasetDefault(){
		posDataset = In.getARFFDatasetFromFile(strPosFileName);
		posDataset.setClassIndex(posDataset.numAttributes() - 1);
		unlDataset = In.getARFFDatasetFromFile(strUnlFileName);
		unlDataset.setClassIndex(unlDataset.numAttributes() - 1);
	}
	
	public void setOptions(String strOptions) throws Exception {
		strAlgorithm = strOptions;
	}
	
	public void setDataset(Instances posData, Instances unData) throws Exception{
		posDataset = posData ;
		posDataset.setClassIndex(posDataset.numAttributes() - 1);
		unlDataset = unData ;
//		Out.printInstances(unData);
		unlDataset.setClassIndex(unlDataset.numAttributes() - 1);
	}
	
//	training
	/**
	 * 传入的数据是PU数据，a值已确定，而且应该是只是训练集和第一测试集（计算最小错误率）
	 */
	@Override
	public void buildClassifier(Instances data)throws Exception{

//		spilt the POS dataset  
		Instances[] two = new Instances[2];
		two = MrtUtils.divileIncsByNum(posDataset, 0.667);
		Instances posLearnData = two[0];
		Instances posTestData = two[1];

//		spilt the UNL dataset
		two =  MrtUtils.divileIncsByNum(unlDataset, 0.667);
		Instances unLearnData = two[0];
		Instances unTestData = two[1];
		
//		Out.println("unLearnData:");
//		Out.println(unLearnData);
//		Out.println("unTestData:");
//		Out.println(unTestData);

		Instances mergeLearnData = MrtUtils.mergetIncs(posLearnData, unLearnData);
//		Instances mergeTestData = MrtUtils.mergetIncs(posTestData, unTestData);  - - 不需要合并
		
//		Out.println("mergeLearnData:");
//		Out.prtIncsDataln(mergeLearnData);
//		Out.println("mergeTestData:");
//		Out.prtIncsDataln(mergeTestData);
		
//		todo: 可将生成好的文件写入本地并打印测试，持久化
//		经测试，本地输出Ok    
		
//		建立9个不同先验概率分布的模型，然后对每一个模型计算结果，10次求平均
		c45posunl = new ClassifyPOSC45[9];
		for(int i = 0 ; i < 9 ; i++){
			c45posunl[i] = new ClassifyPOSC45((i + 1) / 10.0); //double 保留一位小数
			c45posunl[i].setDataset(posLearnData, unLearnData);
			c45posunl[i].setOptions(strAlgorithm);
			c45posunl[i].buildClassifier(mergeLearnData);   
//			Print the object
//			Out.println(c45posunl[i].toString()); 
		}
		
		
		
//		select best DF
		double dEstimate[] = new double[9];
		for(int i = 0;  i< 9 ; i++){
			dEstimate[i] = evaluateBaseEstimate(c45posunl[i], posTestData, unTestData);
		}
		
		int nBestIndex  = Utils.minIndex(dEstimate);
		Out.println("the best dDF--->" +( nBestIndex + 1) / 10.0);
		
		claC45posunl = new ClassifyPOSC45((nBestIndex + 1) / 10.0);
		claC45posunl.setDataset(posLearnData, unLearnData); // - -
		claC45posunl.setOptions(strAlgorithm);
		claC45posunl.buildClassifier(mergeLearnData);
		
		printBasePerformance(In.getARFFDatasetFromFile("datasets/output/fTest.arff"));
		
	}//end of method of buildClassifer
	
	
	public double classifyInstance(Instance instance)throws Exception{
		return claC45posunl.classifyInstance(instance);
	}
	
	public void printBasePerformance(Instances testDataset){
		Out.println("The aa is --->" + aa );
		try {
			double auc = 0.0 , f1= 0.0, pD = 0.0 , pF = 0.0;
			double pFtem ;
			Evaluation eval ;
			for(int i = 0; i < c45posunl.length ; i++){
				for(int j = 0 ; j < 10 ; j++){
					eval = new  Evaluation(testDataset);
					eval.evaluateModel(c45posunl[i], testDataset);
//					PrintfFormat pf = new PrintfFormat("%7.4f");
//					 Out.println("ACCURACY by [" + i + "] : "
//					 + pf.sprintf(1 - eval.errorRate()));
					pFtem = eval.weightedFalsePositiveRate() /
						(eval.weightedFalsePositiveRate() + eval.weightedTrueNegativeRate());
					auc = auc + eval.weightedAreaUnderROC();
					f1 = f1 + eval.weightedFMeasure() ; 
					pD = pD + eval.weightedRecall();
					pF = pF + pFtem ;
				}
					
				Out.println(i+"] weightedAUC: " + (auc / 10 * 1.000));
				Out.println(i+"] weightedFMeasure: " + (f1 / 10 * 1.000));
				Out.println(i+"] weightedRecall(PD): " + (pD / 10 * 1.000));
				Out.println(i+"] weighted(PF): " + (pF / 10 * 1.000));
				pFtem = 0.0;
				auc = 0.0;
				f1 = 0.0;
				pD = 0.0;
				pF = 0.0;
			}

			Out.println("===============================================================");
			MainTestPOSC45.pritnMemory();
			SimpleDateFormat df = new SimpleDateFormat(" HH:mm:ss:SSS");
			System.out.println( " experiment Finished:" + df.format(new Date()));

		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	
	/**
	 * 通过比较最小错误率，来从枚举的df值中得到最优值
	 */
	double evaluateBaseEstimate(ClassifyPOSC45 c45posunl, Instances posTestData,
			Instances unTestData)throws Exception{
		double dPre ;
		int nPosError = 0 ;
		int nUnError = 0 ;
		double fdPre = 0.0 ;
		for(int j = 0 ; j< 10 ; j++){
//			evaluate on POS dataset
			for(int i = 0 ;i < posTestData.numInstances() ; i++){
				Instance sample = posTestData.instance(i);
				dPre = c45posunl.classifyInstance(sample);
				if(Utils.eq(dPre, 1)){
					nPosError++;
				}
			}
//			evaluate on UN dataset		
			for(int i=0; i< unTestData.numInstances() ;i++){
				Instance sample = unTestData.instance(i);
				dPre = c45posunl.classifyInstance(sample);
				if (Utils.eq(dPre, 0)) { // - -
					nUnError++;
				}
			}
			
			dPre = 2 * nPosError / posTestData.numInstances() + nUnError / unTestData.numInstances(); //  - - 
			fdPre += dPre ; 
			
		}
		
//		fdPre = fdPre / 10 * 1.0;
		Out.println("fdPre--->"+fdPre);
		return fdPre;
	}
	


	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(strPosFileName);
		sb.append(": ");
		sb.append(posDataset);
		sb.append(" \n");
		sb.append(strAlgorithm);
		return sb.toString();
	}
	
	
	
	

}
