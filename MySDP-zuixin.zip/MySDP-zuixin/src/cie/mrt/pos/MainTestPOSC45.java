package cie.mrt.pos;

import java.text.DecimalFormat;

import utils.In;
import utils.MrtUtils;
import utils.Out;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.instance.SMOTE;
import cie.mrt.trdf.RandomDecisionForest;

public class MainTestPOSC45 {
//the output file
	public static final String outputPosFile = "datasets/output/outposdata.arff";
	public static final String outputUnlFile = "datasets/output/outunldata.arff";
	public static final String fTestFile = "datasets/output/fTest.arff";
	public static final String tarPUTrain = "datasets/output/tarPUTrain.arff";
	
//	target File
	public static final String entryPnFile = "datasets/pckc/0kc3-numeric.arff";
	
	public static final String auxFile_cm1 = "datasets/pckc/cm1.arff";
	public static final String auxFile_pc1 = "datasets/pckc/pc1-numeric.arff";
	public static final String auxFile_PC1d = "datasets/pckc/PC1d.arff";
	public static final String auxFile_pc3 = "datasets/pckc/pc3.arff";
	public static final String auxFile_PC3d = "datasets/pckc/PC3d.arff";
	public static final String auxFile_PC4dd = "datasets/pckc/PC4dd.arff";
	public static final String auxFile_PC4d = "datasets/pckc/PC4d.arff";
	
	public static final String[] entryFiles = {auxFile_cm1 , auxFile_pc1 , auxFile_PC1d ,
		auxFile_pc3 ,auxFile_PC3d, auxFile_PC4dd , auxFile_PC4d};
	
	public static Instances fTestData ;
	public static Instances outptPosSet ;
	public static Instances outptUnlSet ;
//	public static Instances tarTrainData ;
	
	public static void main(String[] args) throws Exception{
		long startTime = System.currentTimeMillis();
		
//		PosC45ExP();   // finished!!?
//		pritnMemory();
		
//		multiSourceTransfer();
		transferRDF_ExP();
		finalPOSC45_Exp();

		long endTime = System.currentTimeMillis();
		System.out.println("程序运行时间："+(endTime - startTime)+"ms");
		
	}
		 		
	public static void PosC45ExP()throws Exception{	
		PosC45 classifier = new PosC45();
//		1.读入数据集,并解决不平衡问题
		Instances entryData = In.getARFFDatasetFromFile(auxFile_cm1);
		Instances smoteDS = staticSmote(entryData);
//		2.将平衡后数据集分成训练和F测试  各占0.5 保持PN比例
		Instances[] trainFTestData = MrtUtils.divideIncs(smoteDS, 0.75); // 0.667 0.75
		fTestData = trainFTestData[1]; // fTestData 作为最终测试集，得出一切评价指标
//		tarTrainData = trainFTestData[0];
		Out.outputDataFile(fTestFile, fTestData);
		
		
//	3. 分别取a=0.2  0.4  0.6来构造PU数据 , 这里的data是outputPosFile和outputUnlFile的合集
			Instances tarPUdata[] = MrtUtils.pnToPuWriteOrNot(trainFTestData[0], 0.2 ,true); 
//			outptPosSet = In.getARFFDatasetFromFile(outputPosFile);
//			outptUnlSet = In.getARFFDatasetFromFile(outputUnlFile);
			Out.outputDataFile(tarPUTrain, tarPUdata[0]);
			
			/** 以上函数经测试，正确， 符合要求
			 *  4.已得到pu数据集，序列化在本地，读入数据集然后建模、测试
			 * */
			classifier.setAa(0.2); //0.2  0.4  0.6
			classifier.setDataset(tarPUdata[1], tarPUdata[2]);  
			classifier.buildClassifier(tarPUdata[0]);
			
	}
	
	
	/**
	 *  主实验：随机决策森林下的实例迁移，将计算出的迁移集写入到本地，后再用POSC45跑结果  
	 *  修改RandomForest  Bagging  
	 */
	public static void transferRDF_ExP()throws Exception{
//		1.构建分类器，默认设置M= 棵随机树
		RandomDecisionForest rdfClassifier = new RandomDecisionForest();
//		2.传入辅助集来进行  样本迁移,传入前需要先改PN—>PU 在设置属性集时就确定
		Instances balAuxDS =dynamicSmote(In.getARFFDatasetFromFile(auxFile_PC4dd));
		
//		Out.println(balAuxDS);
//		Out.outputDataFile("balAux.arff", balAuxDS);

		DecimalFormat df = new DecimalFormat("0.00");
//		生成随机【0.2-0.6）保留两位的小数 aaa 
//		double aaa = Double.parseDouble(df.format(0.01 + 0.4 * Math.random()));
		double aaa = 0.2;
		Instances puAuxDS[] =  MrtUtils.pnToPuWriteOrNot(balAuxDS, aaa, false); // 0.2  0.4  0.6
		
		
//		Instances puResult = rdfClassifier.setDatasetReturnPUIncs(balAuxDS, 0.2);
//		rdfClassifier.setAa(0.2);

		rdfClassifier.setDataset(puAuxDS[0], 0.2);
		Out.println("aaa--->" + aaa);
		rdfClassifier.buildClassifier(puAuxDS[0]); //传入的是本类中的puData
	}
	
//	{entryPnFile , auxFile_cm1 , auxFile_pc1 , auxFile_PC1d ,	auxFile_pc3 ,auxFile_PC3d, auxFile_PC4dd , auxFile_PC4d};
	public static void multiSourceTransfer()throws Exception{
		RandomDecisionForest rdf = new RandomDecisionForest();
		Instances auxDS1 = In.getARFFDatasetFromFile(auxFile_pc3);
		Instances auxDS2 = In.getARFFDatasetFromFile(auxFile_PC3d);
//		下面3行是二源迁移到三源迁移 
		Instances auxDS3 = In.getARFFDatasetFromFile(auxFile_PC4dd);
		Instances merDS1 =  MrtUtils.mergetIncs(auxDS1, auxDS2);
		Instances mergebalDS = dynamicSmote(MrtUtils.mergetIncs(auxDS3, merDS1));
		
//		Instances mergebalDS = dynamicSmote(MrtUtils.mergetIncs(auxDS1, auxDS2));

		Instances puAuxDS[] =  MrtUtils.pnToPuWriteOrNot(mergebalDS, 0.2, false);
		
		Out.println("aaa--->" + 0.2);
		rdf.setDataset(puAuxDS[0], 0.2);
		rdf.buildClassifier(puAuxDS[0]);
	}
	
	public static void finalPOSC45_Exp()throws Exception{
		PosC45 otherClasifer = new PosC45();
//		将迁移集与本来的tarTrain集合并  为mergetData
		Instances transfer = In.getARFFDatasetFromFile("datasets/output/transfer03.arff");
		Instances tarTrain  = In.getARFFDatasetFromFile("datasets/output/tarPUTrain.arff");
		Instances mergeData = MrtUtils.mergetIncs(transfer, tarTrain);
		Instances balMergeDS = dynamicSmote(mergeData);
//		将mergeData 分开POS 和  UNL   然后分别传入otherClasifer
		Instances[] twoIncs = MrtUtils.spiltIncsByClass(balMergeDS);
//		test : pass
//		Out.println("twoIncs[0].numInstances() : " + twoIncs[0].numInstances());
//		Out.println("twoIncs[1].numInstances() : " + twoIncs[1].numInstances());
//		Out.println(MrtUtils.countPUnum(mergeData, 0));
//		Out.println(MrtUtils.countPUnum(mergeData, 1));
		
		otherClasifer.setDataset(twoIncs[0], twoIncs[1]);
		otherClasifer.buildClassifier(mergeData);
		
	}
	
	public static void pritnMemory(){
		Runtime r = Runtime.getRuntime();
		long mem = (r.totalMemory() - r.freeMemory() ) / 1024 / 1024;
		Out.println("内存使用量：" + mem + "MB");
	}
	
	/**
	 *  将传入的数据集进行SMOTE静态平衡，
	 */
	public static Instances staticSmote (Instances ds )throws Exception{
		SMOTE smote =  new SMOTE();
		int seed = (int)(Math.random() * 10);
		String[] options = {"-S",String.valueOf(seed) ,"-P","400.0" ,"-K" ,"7"};
//		-P  percentage 100.0 指对再增加一倍   500.0 指增加5倍  默认增加少类别样本
//		-K  K临近样本中 

//		int pCount = MrtUtils.getPUnumber(ds)[0];
//		int uCount = MrtUtils.getPUnumber(ds)[1];
//		double ratio = (double) uCount / pCount ;
//		下面的参数的默认，该函数会计算最佳比例动态平衡数据的
//		options[3] = Double.toString(Math.floor(ratio) * 100.0 );  // 动态过采样平衡数据
		
		Instances smoteIncs = null ;
		smote.setOptions(options);
		smote.setInputFormat(ds);
		smoteIncs = Filter.useFilter(ds, smote);
		return smoteIncs ;
	}
	
	public static Instances dynamicSmote (Instances ds )throws Exception{
		SMOTE smote =  new SMOTE();
		int seed = (int)(Math.random() * 10);
		String[] options = {"-S",String.valueOf(seed) ,"-P","400.0" ,"-K" ,"7"};
//		-P  percentage 100.0 指对再增加一倍   500.0 指增加5倍  默认增加少类别样本
//		-K  K临近样本中 

		int pCount = MrtUtils.getPUnumber(ds)[0];
		int uCount = MrtUtils.getPUnumber(ds)[1];
		double ratio = (double) uCount / pCount ;
//		下面的参数的默认，该函数会计算最佳比例动态平衡数据的
		options[3] = Double.toString(Math.floor(ratio) * 100.0 );  // 动态过采样平衡数据
		
		Instances smoteIncs = null ;
		smote.setOptions(options);
		smote.setInputFormat(ds);
		smoteIncs = Filter.useFilter(ds, smote);
		return smoteIncs ;
	}

	
	
}
