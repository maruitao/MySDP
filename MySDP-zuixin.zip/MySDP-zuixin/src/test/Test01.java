package test;

import java.util.Random;

import utils.In;
import utils.MrtUtils;
import utils.Out;
import weka.core.Instances;

public class Test01 {
	public static final String POSDATAFILE = "xxLabel.arff";
	public static final String UNLDATAFILE = "xxUnlabel.arff";
	public static final String ALLDATAFILE = "xxTesting.arff";

	// the output file
	public static final String outputPosFile = "datasets/output/outposdata.arff";
	public static final String outputUnlFile = "datasets/output/outunldata.arff";
	public static final String fTestFile = "datasets/output/fTest.arff";
	public static final String trainFile = "datasets/output/train.arff";
	// target File
	public static final String entryPnFile = "datasets/pckc/0kc3-numeric.arff";
	public static final String entryPnFile1 = "datasets/pckc/PC1d.arff";
	public static final String entryPnFile2 = "datasets/pckc/pc3.arff";
	// auxiliary file
	public static final String auxFile_cm1 = "datasets/pckc/cm1.arff";
	public static final String auxFile_pc1 = "datasets/pckc/pc1-numeric.arff";
	public static final String auxFile_PC1d = "datasets/pckc/PC1d.arff";
	public static final String auxFile_pc3 = "datasets/pckc/pc3.arff";
	public static final String auxFile_PC3d = "datasets/pckc/PC3d.arff";
	public static final String auxFile_PC4d = "datasets/pckc/PC4d.arff";
	public static final String auxFile_PC4dd = "datasets/pckc/PC4dd.arff";
	
	
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Instances ds1 = In.getARFFDatasetFromFile("datasets/output/fTest.arff");
		Instances testDS[]  = MrtUtils.resampleByPutback(ds1, 3);
		Out.outputDataFiles(ALLDATAFILE, testDS);

	}
	
	
	
	public static void modifyIncs(Instances data)throws Exception{
		Out.printInstances(data);
		Out.printCutLine1();
		data = data.resample(new Random());
		Out.printInstances(data);
	}
	
	
	public static Instances[] testAbso(Instances data)throws Exception{
		Instances[] result = MrtUtils.divileIncsByNum(data, 0.4);
		return result;
	}
	
	
	public static void testValueIndexAfterRandom()
			throws Exception{
		Instances data = readTestData(ALLDATAFILE);
		data.sort(37);
		Out.println(data);
		Out.printCutLine1();
		
		data.randomize(new Random());
		data.sort(37);
		Out.println(data);
	}  
	
	public static Instances readTestData(String filename) throws Exception{
		Instances data = In.getARFFDatasetFromFile(filename);
		return data;
	}
	
	
	/**
	 * 测试如何打乱数据集样本排列 
	 */
	public static void testRandom() throws Exception{
		Instances data = readTestData(POSDATAFILE);
		Out.println(data);
		Out.printCutLine1();
		data.randomize( new Random());  //经测试，该函数确实可以随机打乱Incs
		Out.println(data);
	}

}
