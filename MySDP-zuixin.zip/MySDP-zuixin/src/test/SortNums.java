package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class SortNums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i  = 0 ;
		List<Integer> nums =  new ArrayList<Integer>();
		Scanner scan = new Scanner(System.in);
		
		while(scan.hasNext()){
			nums.add(i, scan.nextInt());
			i++;
		}
		System.out.println(nums.toString());
		
		
	}

}
