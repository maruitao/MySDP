/*
 * Created on: 2005-7-22
 * 
 * BY: Zhang Yang
 * PROBECT: common
 * 
 * Goal: get information about a class.
 *       A library class  
 */

package utils;

public class ClassInfo {

    public static void main(String args[]){
        /*System.out.println(AllTool.SprintfInt(10,4));
        System.out.println(AllTool.SprintfInt(1000,4));
        System.out.println(AllTool.SprintfInt(10000,4));

        System.out.println(AllTool.SprintfInt("10",4));
        System.out.println(AllTool.SprintfInt("1000",4));
        System.out.println(AllTool.SprintfInt("10000",4));

        String [] strFile = AllTool.getAllFileName(".",".txt");
        for (int i=0;i<strFile.length;i++)
            System.out.println(strFile[i]);*/

         java.net.URL classUrl =
            new ClassInfo().getClass().getResource("/texttool/data/STOPWORD.txt");
        System.out.println(classUrl);
        
    }

    public static String GetClassName(Object o){
    	String str = o.getClass().getName();
    	str=str.substring(str.lastIndexOf(".")+1);
    	return str;
    }
}
