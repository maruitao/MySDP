package utils;

import java.io.BufferedReader;
import java.io.FileReader;

import weka.core.Instances;

public class In {
	
	public static Instances getARFFDatasetFromFile(String afrrFileName) {
		try {
			Instances result = null;
			BufferedReader br = new BufferedReader(new FileReader(afrrFileName));
			result = new Instances(br);
			result.setClassIndex(result.numAttributes() - 1);
			br.close();
			return result;
		} catch (Exception e) {
			Out.error("Read ARFF Error! ", e);
		}
		return null;
	}
	
	

}
