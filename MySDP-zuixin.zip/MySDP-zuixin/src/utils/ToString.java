/*
 * Created on: 2005-8-10
 * 
 * BY: Zhang Yang
 * PROBECT: tdt
 * 
 * Goal: 
 *       A library class  
 */

package utils;

import java.util.*;

public class ToString {
   public static final String strLineSeperator=System.getProperty("line.separator");
    
    public static String toString(Set s){
        String str="";
        
        Iterator it=s.iterator();
        while (it.hasNext()){
            str=str+it.next()+strLineSeperator;
        }
        return str;
    }

    public static String toString(double d[]){
        String str="";
        for (int i=0;i<d.length;i++) str+=d+" ";
        return str;
    }
}

