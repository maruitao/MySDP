package utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import weka.core.Instance;
import weka.core.Instances;

public class Out {

	/**
	 * 打印数据集，一行 一条样本
	 * 
	 * @param data
	 * @throws Exception
	 */
	public static void printInstances(Instances data) throws Exception {
		for (int i = 0; i < data.numInstances(); ++i)
			System.out.println(i + 1 + ": " + data.instance(i));
	}
	
	public static void printIncsHead(Instances data)throws Exception{
		for(int i =0;i<data.numAttributes();i++){
			System.out.println(i+"  "+data.attribute(i));
		}
	}
	
	public static void printCutLine1(){
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	}
	public static void printCutLine2(){
		System.out.println("------------------------------------------");
	}
	public static void printCutLine3(){
		System.out.println("================================================");
	}
	public static void printCutLine5(){
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++");
	}
	
	public static void printIncsRealation(Instances data)throws Exception{
		System.out.println(data.relationName());
	}
	
	public static void outputDataFile(String local, Instances file)throws Exception{
		BufferedWriter bw = new BufferedWriter(new FileWriter(local));
		bw.write(file.toString());
		bw.flush();
		bw.close();
		SimpleDateFormat df = new SimpleDateFormat(" HH:mm:ss:SSS");
		System.out.println(file.relationName() + " has already writen to " 
				+ local + df.format(new Date()));
	}
	
	public static void outputDataFiles(String local ,Instances[] datas)throws Exception{
		BufferedWriter bw = new BufferedWriter(new FileWriter(local));
		int i;
		for(i = 0 ;i < datas.length ; i++){
			bw.write("\n第"+ i +"个数据集\n");
			bw.write(datas[i].toString());
			bw.flush();
		}
		bw.write("\n一共有"+ i +"个数据集");
		bw.close();
	}
	
//	public static void writeFTest2Arff
	
	public static void outputDataFile(String local , List l)throws Exception{
		BufferedWriter bw = new BufferedWriter(new FileWriter(local)); 
		PrintWriter pw = null;
		
	}
	
	
	public static void stop(String str){
		println(str);
		println("STOP HERE FOR DEBUG *********************************");
		System.exit(0);
	}
	public static void stop(){
		println("STOP HERE FOR DEBUG *********************************");
		System.exit(0);
	}
	


	public static void outToArff(String fileName,Instances data)throws Exception{
		BufferedWriter bw =new BufferedWriter(new FileWriter(fileName));
		
		bw.write(data.relationName());
		bw.write("\n");
		for(int i = 0;i<data.numAttributes(); i++){
			bw.write(data.attribute(i).toString());
			bw.write("\n");
		}
		bw.write("@data");
		bw.write("\n");
		for(int i =0; i< data.numInstances() ; i++){
			bw.write(data.instance(i).toString());
			bw.write("\n");
		}
		bw.flush();
		bw.close();
	}
	
	public static void error(String str , Exception e){
		System.err.println("ERROR!! System Stop!");
		System.err.println(str);
		e.printStackTrace();
		System.exit(0);
	}
	
	public static void error(Exception e){
		System.err.println("Error!! System Stop..");
		e.printStackTrace(System.err);
		System.exit(0);
	}

	public static void error(String str){
		System.err.println("ERROR!!! SYSTEM STOP...");
		System.err.println(str);
		System.exit(0);
	}
	
	public static void error(){
		System.err.println("ERROR!!! SYSTEM STOP...");
		System.exit(0);
	}

	public static void println(double d){
		System.out.println(d);
	}
	
	public static void println(String str){
		System.out.println(str);
	}
	
	public static void println(int i){
		System.out.println(i);
	}
	
	public static void printInstanceAndWeight(Instance data ,int index){
		System.out.println(index + ": " + data.toString() 
				+ "  weigth:" + data.weight());
	}
	
	public static void printIncsWithWeight(Instances data
			)throws Exception{
		for(int i = 0; i< data.numInstances() ; i++){
			System.out.println(i + 1 + ": " + data.instance(i) 
					+ "  weigth:" + data.instance(i).weight() );
		}
	}
	
	public static void printMap(Map map)throws Exception{
		Iterator it = map.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry entry = (Map.Entry) it.next();
			Object key =  entry.getKey();
			Object val = entry.getValue();
			System.out.println("key:" + key + "  value:"+ val);
		}
	}
	
	public static void println(Instances data)throws Exception{
		System.out.println(data.relationName());
		for(int i = 0 ; i< data.numAttributes() ; i++){
			System.out.println(data.attribute(i));
		}
		
		for (int i = 0; i < data.numInstances(); ++i)
			System.out.println(i + 1 + ": " + data.instance(i));
	}
	
	public static void println(Instance data)throws Exception{
		System.out.println(data.toString());
	}
	
	public static void prtIncsDataln(Instances data)throws Exception{
		for(int i = 0 ; i< data.numInstances(); i++){
			System.out.println(i + 1 + ": " + data.instance(i));
		}
	}
	
}
