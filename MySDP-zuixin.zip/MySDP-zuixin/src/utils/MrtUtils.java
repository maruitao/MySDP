package utils;

import java.util.Random;

import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;
import weka.filters.Filter;
import weka.filters.supervised.instance.Resample;

public class MrtUtils {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	public static String[] spiltOptions(String opts)throws Exception{
		String[] result = opts.split(" ");
		return result;
	}
	
	/**
	 * 将两个数据集合并成为一个数据集，要求类别空间和特征空间相同
	 * 经测试，该函数准确无误!
	 * @param instances1
	 * @param instances2
	 * @return 合并后的数据集
	 * @throws Exception 数据集的列不一样 
	 */
	public static Instances mergetIncs(Instances instances1, Instances instances2)throws Exception{
//		copy instances1 to result
		Instances result  = new Instances(instances1, 0, instances1.numInstances());
		
		for(int i = 0 ; i < instances2.numInstances() ; i ++){
			result.add(instances2.instance(i));
		}
		result.setClassIndex(result.numAttributes() - 1);
		result.compactify();
//		Out.prtIncsDataln(instances1);
//		Out.printCutLine1();
//		Out.prtIncsDataln(result);
		return result;
	}
	
	public static Instances[] divileIncsByNum(Instances instances ,double aa)
			throws Exception{
		if(aa <= 0 || aa >= 1){
			throw new Exception("a值不合法，应该在(0-1)内");
		}
		else {
			Instances[]  two = new Instances[2]; 
			int count = instances.numInstances();
//			Out.println("all the Incs count: " + count);
//			Out.printCutLine2();
			two[0] = new Instances(instances, 0);
			two[1] = new Instances(instances, 0);
			instances.randomize(new Random());
			for(int i = 0; i < count ; i++){
				if(i  <= count * aa ){
					two[0].add(instances.instance(i));
				}
				else {
					two[1].add(instances.instance(i));
				}
			}
			return  two;
		}
	}
	
	/**
	 * count the Incs(P or U)'s number of instance 
	 * @param dataset  数据集只能是P or  U
	 * @param flag    0 is for P  and 1 is for U
	 * @return	the number of POSDS or UNLDS
	 */
	public static int countPUnum(Instances dataset , int flag )
			throws Exception{
		int result = 0 ;
//		int flag = 0; //0 is P  1 is U
		if(dataset == null)
			return 0 ;
		else {
			if(flag == 0){  // count the POS  number
				for(int i = 0; i < dataset.numInstances() ; i++){
					if(dataset.instance(i).stringValue(37).equals("Y")){
						result++;
					}
					else {
						continue;
					}
				}
			}
			else if(flag == 1){
				for(int i = 0 ; i < dataset.numInstances() ; i++){
					if (dataset.instance(i).stringValue(37).equals("N")) {
						result++;
					}else{
						continue;
					}
				}	
			}
		}
		return result;
	}
	
	/**
	 *  get the dataset P and U  number of instance 
	 * @param dataset  数据集可以是P  or  U  or PU
	 * @return
	 */
	public static int[] getPUnumber(Instances dataset)throws Exception{
		int[] twoNum = new int[2]; // [0] is for P  [1] is for U(N)
		for(int i = 0 ; i< dataset.numInstances() ; i++){
			if(dataset.instance(i).stringValue(37).equals("Y")){
				twoNum[0]++;
			}
			else if(dataset.instance(i).stringValue(37).equals("N")){
				twoNum[1]++;
			}
		}
		return twoNum;
	}
			

	/** 根据数据索引打印数据集中样本信息 和 权重*/
	public static void printInstanceWithWeight(Instances ds , int index)throws Exception{
		System.out.println(ds.instance(index).toString() + " weight: " + ds.instance(index).weight());
	}
		
	
	/**
	 * 	查找看一个数据集中是否有实例样本，若有返回 其找到的索引值，若没有返回-1 
	 */
	public static int  hasInclude(Instances ds , Instance  instance)throws Exception{
		int i ;
		for(i = 0 ; i< ds.numInstances() ; i++){
			if(ds.instance(i).toString().equals(instance.toString())){ 
				return i;
			}else {
				continue ;
			}
		}
		return -1 ;
	}
	
	/**
	 * 从数据集中查找样本实例，返回索引值，若没有返回-1 
	 * @param ds
	 * @param insc 样本实例是以String给出
	 */
	public static int hasInclude(Instances ds ,String  insc)throws Exception{
		int i ;
		for(i = 0 ; i < ds.numInstances() ; i++){
			if(ds.instance(i).toString().equals(insc)){
				return i;
			}
			else
				continue ;
		}
		return -1 ;
	}
	
/**
 *  根据数据集的样本权重来迁移权重高的样本，返回要迁移的数据集
 */
	public static Instances transferIncsByWeight(Instances ds )throws Exception{
		Instances result = new Instances(ds	, 0);
		for(int i  = 0 ; i< ds.numInstances() ;i ++){
			if(Utils.eq(ds.instance(i).weight(), 1.0)){
				continue;
			}else {
				result.add(ds.instance(i));
			}
		}
		result.compactify();
		result.setClassIndex(result.numAttributes() - 1);
		return result ;
	}
	
	/**
	 * 将数据集维持PN比例来划分a倍训练集 1-a倍测试集
	 * @param data 已知数据集
	 * @param a  数量比例，a为第一个集子的比例
	 * @return 分别返回两个集子，第一个样本数a*len 返回集子PN比不变
	 */
	public static Instances[] divideIncs(Instances data, double aa)
			throws Exception {
		if (aa < 0 || aa > 1)
			throw new Exception("a值不合法,a当为(0,1)间小数");
		else {
			Instances[] divideSet = new Instances[2];
			int len = data.numInstances();
			int countP = 0, countN = 0;
			for (int i = 0; i < len; i++) {
				if (data.instance(i).stringValue(37).equals("Y")) {
					countP++;
				}
				else {
					countN++;
				}
			}
//			System.out.println("countP:" + countP + " countN:" + countN);
//			countN = len - countP;

			divideSet[0] = new Instances(data, len);
			divideSet[1] = new Instances(data, len);
			int i, j;
			data.sort(37);
			for (i = 0; i <= countP * aa; i++) {
				divideSet[0].add(data.instance(i));
			}
			for (j = len - 1; j >= countP + countN * (1 - aa); j--) {
				divideSet[0].add(data.instance(j));
			}
			//
			for (i = (int) (countP * aa + 1); i <= j; i++) {
				divideSet[1].add(data.instance(i));
			}
			divideSet[0].compactify();
			divideSet[1].compactify();

			return divideSet;
		}
	}
	/**
	 * 将传入的数据集和a值将PN数据改为PU数据，其中1-a为P中最后保留下来的P
	 * 将1-a倍的P留下来，其余的P和所有的N改为N,视为Unlabeled数据
	 * 该函数中会生成两个Instances posDataset  unlDataset, 其并集为返回值 result
	 * @param dataset 待传入的PN数据集
	 * @param a  比例a=0.2  0.4  0.6
	 * @param isPOSC45  true表示posc45调用， 本地输出 pos和 unl数据集      false表示rdf调用，
	 * @return  返回修改好的数据集 PU P U
	 */
	public static Instances[] pnToPuWriteOrNot(Instances dataset, double a , boolean isPOSC45)
			throws Exception{
		Instances[] result = new Instances[3]; // 分别是PU  P  U 
		if(a < 0 || a > 1){
			throw new Exception("PN数据集转换PU数据集时，a值有误！");
		}
		else {
			
			int len = dataset.numInstances() ; 
			dataset.setClassIndex(dataset.numAttributes() - 1);
			result[0] = new Instances(dataset ,  len);
			result[1] = new Instances(dataset ,  len);
			result[2] = new Instances(dataset ,  len);
			int countP = 0;
//			Instances posDataset = new Instances(dataset, len);
//			Instances unlDataset = new Instances(dataset, len);
			dataset.randomize(new Random());
			dataset.sort(dataset.classIndex());//根据类别标签排序 
//			将前1-a倍的P保留，后面的全部改为N
//			遍历一遍：记录正例样本数，把所有负例加入到unlDataseet
			for(int i = 0; i< len; i++){
				if(dataset.instance(i).stringValue(dataset.classIndex()).equals("Y")){
					countP++;
				}
				else {
					result[2].add(dataset.instance(i));
				}
			}
//			把前（1-a）倍的P加入posDataset，后面的加入到unlDataset
			for(int i = 0 ; i < countP; i++){
				if(i  <  countP * (1 - a)){
					result[1].add(dataset.instance(i));
				}
				else {
					dataset.instance(i).setValue(dataset.classIndex(), "N");
					result[2].add(dataset.instance(i));
				}
			}
//			posDataset.compactify();
//			unlDataset.compactify();
//			result.compactify();
			result[0] = mergetIncs(result[1], result[2]);
			result[0].compactify();
			result[1].compactify();
			result[2].compactify();
			
			result[0].setClassIndex(result[0].numAttributes() - 1);
			result[1].setClassIndex(result[1].numAttributes() - 1);
			result[2].setClassIndex(result[2].numAttributes() - 1);
			
			if(isPOSC45){
//				Out.outputDataFile("datasets/output/outposdata.arff", result[1]);
//				Out.outputDataFile("datasets/output/outunldata.arff", result[2]);
			}else {
//			上两行输出是posc45   下一行输出是rdf
//				Out.outputDataFile("datasets/output/puAuxresult.arff", result[0]);	
			}
		}
		return result;
	}
		
		
	/**
	 * 将PN数据集改成PU数据集，采样多份，每一份都是无放回采样
	 * @param data  数据集
	 * @param num   采样成多少份
	 * @param a		1-a为保留正例比例
	 * @return
	 * 该函数没有被调用 。。
	 */
	@Deprecated 
	public static Instances[] PnToPuRept(Instances data,
			int num ,double  a)throws Exception{
		Instances[]  resultData = new Instances[num];
		Random random = new Random();
		for(int i = 0 ;i < num ;i ++){
			random.nextInt();
			data.randomize(random);
			data.sort(37);
//			resultData[i] = pnToPuWriteOrNot(data, a); - - 
		}
		return resultData;
	}

	/**
	 *  有放回抽样，每次随机打乱，抽取第一个数据
	 */
	public static Instances sampleWithReplacement(Instances data , 
			double percent)throws Exception{
		int dataSize = data.numInstances();
		Instances result =  new Instances(data, 0);
		Random random = new Random();
		random.nextInt();
		while(result.numInstances() < dataSize * percent){
			data.randomize(random);
			result.add(data.instance(0));
		}
		return result ;
	}
	
	/**
	 * 对样本数据集进行随机采样，分保持PN比例变和不变的
	 * 
	 * Test01.java 中间接测试  通过！
	 * @param size    生成多少个Instances数组
	 * @param holdRation   T 表示保持比例
	 */
	public static Instances[] absoRandResample(Instances dataset 
			,double  percent , int size , boolean holdRatio)throws Exception{
		Instances[] resultData = new Instances[size]; // 随机采样生成size份数据 
		Random random = new Random();
		if(holdRatio){ // 当保持比例随机采样时
			for(int i = 0 ;i < size ; i++){
				dataset.randomize(random);
				resultData[i] = divideIncs(dataset, percent)[0];
				resultData[i].setClassIndex(resultData[i].numAttributes() - 1);
			}
		}
		else { // 当不保持PN比例采样
			for(int i = 0 ; i < size ; i++){
				dataset.randomize(random);
				resultData[i] = divileIncsByNum(dataset, percent)[0];
				resultData[i].setClassIndex(resultData[i].numAttributes() - 1);
//				resultData[i] = dataset.resampleWithWeights(random); 
			}
		}
		return resultData;
	}
	
	/**
	 * 从当前数据集中有放回抽样（不保持PN比例），生成size大小个Instances 
	 */
	public static Instances[] resampleByPutback(Instances ds ,int size )throws Exception{
		Instances[]  result =  new Instances[size] ;
//		String[] options= {"-S" , "1"}; 
		Resample resample = new Resample(); // 默认参数{-B 0.0 -S 1 -Z 100.0}
		resample.setInputFormat(ds);
//		使用Resample对象来实现有放回抽样，本质就是简单随机抽样
		for(int i = 0  ; i < size ; i++){
			result[i] = Filter.useFilter(ds, resample);
		}
		return result ;
	}
	

	/**
	 * 将一个数据集按类别分成两个子集 , [0]为正例集  [1]为负例集
	 */
	public static Instances[] spiltIncsByClass(Instances  ds)throws Exception{
		if(ds  ==  null)
			return null ; 
		else{
			Instances[] two =  new Instances[2];
			two[0] = new Instances(ds, 0);
			two[1] = new Instances(ds, 0);
			Instance tmpInce ;
			for(int i = 0 ;i < ds.numInstances() ; i++){
				tmpInce = ds.instance(i);
				if(tmpInce.stringValue(37).equals("Y")){
					two[0].add(tmpInce);
				}
				else {
					two[1].add(tmpInce);
				}
			}
			two[0].setClassIndex(two[0].numAttributes() - 1);
			two[1].setClassIndex(two[1].numAttributes() - 1);
			return two;
		}
	}
	

}//end of class of UtilClass
