package utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class MyMap   {

	public static void main(String[] args){
		
		Map<String, Double> map = new TreeMap<String, Double>();
		map.put("a", 313.21);
		map.put("b", 1313.21);
		map.put("c", 1.21);
		map.put("d", 0.2);
		map.put("e", 0.11);

		List<Map.Entry<String, Double>> list = 
				new ArrayList<Map.Entry<String,Double>>(map.entrySet());
		Collections.sort(list , new Comparator<Map.Entry<String, Double>>() {

			@Override
			public int compare(Entry<String, Double> o1,
					Entry<String, Double> o2) {
				// TODO Auto-generated method stub
				return o1.getValue().compareTo(o2.getValue());
			}
			
		});
		
		for(Map.Entry<String, Double> mapping : list){
			System.out.println(mapping.getKey() + " : " + mapping.getValue());
		}

	}
	
}
