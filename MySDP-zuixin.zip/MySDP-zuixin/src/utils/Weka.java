/**
 *    Date : 2007-8-3 
 *      by : Yang ZHANG  @ UQ
 *   Email : mokuram@itee.uq.edu.au
 *           zhangyang@nwsuaf.edu.cn
 *    
 * Project : One-class Classification of Data Streams
 *
 * Description:
 *
 */
package utils;
import java.util.*;

import weka.core.*;
import weka.classifiers.*;

public class Weka {
    public static double getFeatureWeight(int nFeatureIndex,double dRanked[][]){
        for (int i=0;i<dRanked.length;i++){
            if (dRanked[i][0]==nFeatureIndex) return dRanked[i][1];
        }
        
        Out.stop("CANNOT FIND THE FEATURE! ERROR");
        
        return 0;
    }
    // get classifier option
    public static String getClassifierOptions(Classifier cla){
        String str=ConsoleRun.title(cla);
        String options[]=cla.getOptions();
        
        for (int i=0;i<options.length;i++){
            str+=" "+options[i];
        }
        
        return str;
    }
    // put all the samples in dataset 2 into dataset1
    public static void addDataset(Instances set1, Instances set2){
        for (int i=0;i<set2.numInstances();i++){
            set1.add(set2.instance(i));
        }
    }

    // get a subset of the dataset, with sampleSize samples
    public static Instances createSubsampleWithoutReplacement(Instances dataset, int sampleSize) {
        Random random=new Random(100);

        int origSize=dataset.numInstances();

        if (sampleSize > origSize) {
            sampleSize = origSize;
            System.err.println(
                    "Resampling with replacement can only use percentage <=100% - "
                    + "Using full dataset!");
        }

        Vector<Integer> indices = new Vector<Integer>(origSize);
        Vector<Integer> indicesNew = new Vector<Integer>(sampleSize);

        // generate list of all indices to draw from
        for (int i = 0; i < origSize; i++)
            indices.add(i);

        // draw X random indices (selected ones get removed before next draw)
        for (int i = 0; i < sampleSize; i++) {
            int index = random.nextInt(indices.size());
            indicesNew.add(indices.get(index));
            indices.remove(index);
        }

        Instances subData=new Instances(dataset,10);
        for (int i=0;i<indicesNew.size();i++){
            int index=indicesNew.get(i).intValue();
            subData.add(dataset.instance(index));
        }

        return subData;
    }

    // parse the command used in weka
    public static String [] parseCommand(String strCommand){
        StringTokenizer st=new StringTokenizer(strCommand);

        List l=new ArrayList();
        while(st.hasMoreTokens()){
            l.add(st.nextToken());
        }

        String str[]=new String[l.size()];
        for (int i=0;i<l.size();i++) str[i]=(String)l.get(i);

        return str;
    }

    public static String formatLogString(String strOriginal, String strLineHead){
        return strOriginal.replace("\n",ToString.strLineSeperator+strLineHead);
    }

    public static void ARFF2SVM(String strArff, String strSVM) throws Exception{
        Out.println(strArff+" ---> "+strSVM+" ...");
        Instances dataset=In.getARFFDatasetFromFile(strArff);
        int nFeature=dataset.numAttributes();

        List l=new ArrayList();
        for (int i=0;i<dataset.numInstances();i++){
            Instance sample=dataset.instance(i);
            String str="";
            if (sample.value(nFeature-1)==0) str+="+1 ";
            else str+="-1 ";

            for (int j=0;j<nFeature-1;j++) {
                if (sample.value(j)!=0) str+=(1+j)+":"+sample.value(j)+" ";
            }
            l.add(str);
        }

//        Out.outputDataFile(strSVM, l);  by Mrt
    }

    public static void ARFF2SVM(Instances dataset, String strSVM){
        Out.println("Creating "+strSVM+" ...");
        int nFeature=dataset.numAttributes();

        List l=new ArrayList();
        for (int i=0;i<dataset.numInstances();i++){
            Instance sample=dataset.instance(i);
            String str="";
            if (sample.value(nFeature-1)==0) str+="+1 ";
            else str+="-1 ";

            for (int j=0;j<nFeature-1;j++) {
                if (sample.value(j)!=0) str+=(j+1)+":"+sample.value(j)+" ";
            }
            l.add(str);
        }

//        Out.outputDataFile(strSVM, l); by Mrt
    }

    // Open a TXT file for output the string content
    public static String ARFF2String(Instances dataset){
        String str;

        str ="% Feature Count : "+dataset.numAttributes()+ToString.strLineSeperator;
        str+="% Sample Count  : "+dataset.numInstances()+ToString.strLineSeperator;

        AttributeStats att=dataset.attributeStats(dataset.numAttributes()-1);
        String str2=att.toString();
        str2=str2.replace("\n", ToString.strLineSeperator+"% ");

        str+="% "+str2;

        str+=ToString.strLineSeperator+ToString.strLineSeperator+dataset.toString();

        return str;
    }

    // Open a TXT file for output the string content
    public static String ARFF2StringWithWeight(Instances dataset){
    	String str="% ==== DATASET ==================================================== {";
    	str+=ToString.strLineSeperator;
    	
        str+="% Feature Count : "+dataset.numAttributes()+ToString.strLineSeperator;
        str+="% Sample Count  : "+dataset.numInstances()+ToString.strLineSeperator;

        AttributeStats att=dataset.attributeStats(dataset.numAttributes()-1);
        String str2=att.toString();
        str2=str2.replace("\n", ToString.strLineSeperator+"% ");

        str+="% "+str2;

        str+=ToString.strLineSeperator+ToString.strLineSeperator;
        
    	str+="@relation "+dataset.relationName();
    	str+=ToString.strLineSeperator;
    	str+=ToString.strLineSeperator;
    	
    	for (int i=0;i<dataset.numAttributes();i++){
    		str+=dataset.attribute(i);
    		str+=ToString.strLineSeperator;
    	}
    	str+=ToString.strLineSeperator;

    	str+="@data"+ToString.strLineSeperator;
    	for (int i=0;i<dataset.numInstances();i++){
    		str+=dataset.instance(i)+"   % "+dataset.instance(i).weight();
    		str+=ToString.strLineSeperator;
    	}
    	str+=ToString.strLineSeperator;
    	str+=ToString.strLineSeperator;
    	
    	str+="% ==== DATASET ==================================================== }";
    	return str;
    }

    public static String getArffDescription(Instances dataset){
        String str;

        str ="% Feature Count : "+dataset.numAttributes()+ToString.strLineSeperator;
        str+="% Sample Count  : "+dataset.numInstances()+ToString.strLineSeperator;

        AttributeStats att=dataset.attributeStats(dataset.numAttributes()-1);
        String str2=att.toString();
        str2=str2.replace("\n", ToString.strLineSeperator+"% ");

        str+="% "+str2;

        return str;

    }
    
    // resample with weights, and return a sample set with nSize samples
    // parts of this algorithm is copied from Instances class
    static public Instances resampleWithWeights(Instances dataset, Random random, 
			int nSize) {

		Instances newData=new Instances(dataset,10);
		
		double weights[]=new double[dataset.numInstances()];
		for (int i=0;i<dataset.numInstances();i++){
			weights[i]=dataset.instance(i).weight();
		}


		double[] probabilities = new double[weights.length];
		double sumProbs = 0, sumOfWeights = Utils.sum(weights);
		for (int i = 0; i < weights.length; i++) {
			sumProbs += random.nextDouble();
			probabilities[i] = sumProbs;
		}
		Utils.normalize(probabilities, sumProbs / sumOfWeights);

		// Make sure that rounding errors don't mess things up
		probabilities[weights.length - 1] = sumOfWeights;
		int k = 0; int l = 0;
		sumProbs = 0;
		while ((k < nSize && (l < nSize))) {
			if (weights[l] < 0) {
				throw new IllegalArgumentException("Weights have to be positive.");
			}
			sumProbs += weights[l];
			while ((k < nSize) &&
					(probabilities[k] <= sumProbs)) { 
				newData.add(dataset.instance(l));
				newData.instance(k).setWeight(1);
				k++;
			}
			l++;
		}
		return newData;
	}

    
    public static void main(String[] args) throws Exception{
        Weka.ARFF2SVM("train0.arff", "train0.svm");
        Weka.ARFF2SVM("train1.arff", "train1.svm");
        Weka.ARFF2SVM("train2.arff", "train2.svm");
        Weka.ARFF2SVM("train3.arff", "train3.svm");
        Weka.ARFF2SVM("train4.arff", "train4.svm");
        Weka.ARFF2SVM("train5.arff", "train5.svm");
        Weka.ARFF2SVM("train6.arff", "train6.svm");
        Weka.ARFF2SVM("train7.arff", "train7.svm");
        Weka.ARFF2SVM("train8.arff", "train8.svm");
        Weka.ARFF2SVM("train9.arff", "train9.svm");

    }
}
