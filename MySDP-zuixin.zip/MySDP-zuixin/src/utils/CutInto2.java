package utils;

import java.util.Iterator;
import java.util.TreeSet;

import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.supervised.instance.Resample;

public class CutInto2 extends Resample {
	
	private static final long serialVersionUID = 2292488521082026816L;
	protected TreeSet setA= new TreeSet();
	protected TreeSet setB = new TreeSet();
	
	/**
	 * 将数据集（PU数据集）按比例分开
	 * @param nRandomInt
	 * @param nPercent
	 * @param originalDataset
	 * @return
	 */
	public   Instances[] randomize(int nRandomInt ,int nPercent, Instances originalDataset){
		
		try {
			originalDataset.setClassIndex(originalDataset.numAttributes() -1);
			System.out.println("size of original dataset: " + originalDataset.numInstances());
			
			String strOption = "-S " + nRandomInt + " -Z " + nPercent + 
					" -no-replacement";
			Out.println(strOption);
			String[] options = MrtUtils.spiltOptions(strOption);
			for(String str: options){
				Out.println(str);
			}
			CutInto2 resample = new CutInto2();
			resample.setOptions(options);
			resample.setInputFormat(originalDataset);
			Filter.useFilter(originalDataset, resample);
			
			/**WT: 这里如何把一个数据集随机按数量分割成 互补的两部分*/
			Instances[] two = new Instances[2];
			two[0] = resample.getPartZ(originalDataset);
			two[1] = resample.getPartNotZ(originalDataset);
			
			return two;
			
		} catch (Exception e) {
			Out.error("PU数据集随机分割出错！", e);
		}
		return null;
	}
	
	/**
	 * 将数据集转换成Treeset对象，方便后面打印，不指定泛型
	 * @param set
	 * @param dataset
	 * @return
	 */
	protected Instances getPart(TreeSet set,Instances dataset){
		Instances newDataset = new Instances(dataset,10);
		
		Iterator it =set.iterator();
		while(it.hasNext()){
			int index = ((Integer)it.next()).intValue();
			newDataset.add(dataset.instance(index));
			
		}
		return newDataset;
	}
	
	public Instances getPartZ(Instances dataset){
		return getPart(setA, dataset);
	}
	
	public Instances getPartNotZ(Instances dataset){
		return getPart(setB, dataset);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
